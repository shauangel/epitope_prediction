#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 18:46:14 2021

@author: shauangel
"""

from pymongo import MongoClient
import pytz

DB = MongoClient('mongodb+srv://angel:cafe6428@epred-cluster.s70gp.mongodb.net/test?authSource=admin&replicaSet=atlas-ovivm1-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true')['EVPsys']

EPITOPE_COLLECTION = DB['EPITOPE']
SEQ_COLLECTION = DB['SEQ']
PRED_COLLECTION = DB['PREDICTION']


pacific = pytz.timezone('Asia/Taipei')



if __name__ == "__main__":
    test = [i for i in EPITOPE_COLLECTION.find()]
    for i in test:
        print(test)