#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 15:18:21 2021

@author: shauangel
"""
from systemParse import ABCpred, BcePred, BCPREDS, Bepipred2, LBtope, LEPS
import db_connection as DB

#error_abcpred = ["O83867", "P49908"] #reduction of non-canonical amino acids
#error_LEPS = ["C6KTB7"] #length exceed

if __name__ == "__main__":
    
    #datas = DB.SEQ_COLLECTION.find()
    ##progress rate
    total = str(2646)
    curr_seq = 0
    
    ##預測系統設定
    predictor = "LBtope"
    sys = LBtope()
    
    
    datas = DB.SEQ_COLLECTION.find()
    ##implement
    for data in datas:
        
        curr_seq += 1
        
        #重啟機制
        ##序列編號為1~2646
        ##ex: 從第30條序列開始, 此處塡30
        if curr_seq <= 0:
            print(str(curr_seq) + ' / ' + total)
            continue
        
        #結束
        #ex: 欲抓取到第300條, 此處塡300
        elif curr_seq > 500:
            break
        
        FASTA = "\n".join([data['FASTA'].split('\n')[0],"".join(data['FASTA'].split('\n')[1:])])
        prediction = sys.parse_web(FASTA)
        
        #檢查長度
        length_ck = len(FASTA.split('\n')[1]) == len(prediction)
        
        #result
        print(prediction)
        print("seq_id: " + data['seq_id'])
        print("length_check: " + str(length_ck))
        print("=============================")
        
        
        #update db
        query = {"seq_id" : data['seq_id']}
        if length_ck:
            settings = { "$set" : { predictor : prediction } }
        else:
            settings = { "$set" : { predictor : "err" } }
            
        DB.SEQ_COLLECTION.update_one(query, settings)
        
        print(str(curr_seq) + ' / ' + total)
        
        